바이러스가 아닙니다 종이 고양이 — beta
this is not a virus. it’s a paper cat. — beta

Windows 10/11 (x64)

실행
- `koldkitty.exe` 실행.
- 다시 실행하면 고양이가 한 마리 더 나타납니다.
- 고양이를 우클릭하면 해당 고양이만 종료됩니다.
- 고양이를 클릭하면 종이로 변하고, 약 4초 후 브라우저가 열립니다.

첫 실행
- 인터넷 연결 필요.
- 전용 Java 21 런타임을 Adoptium에서 내려받아 실행 파일 옆의 `.koldkitty` 폴더에 보관합니다.
- 시스템 전체 Java 설치 및 관리자 권한은 필요하지 않습니다.
- 코드 서명되지 않은 베타 버전으로, Windows 보안 경고가 표시될 수 있습니다.

작업 노트
https://installation.koldsleep.com/

---

Windows 10/11 (x64)

Run
- Open `koldkitty.exe`.
- Open it again to add another cat.
- Right-click a cat to close that instance.
- Click a cat to turn it into paper; a browser page opens after approximately four seconds.

First launch
- Internet connection required.
- A private Java 21 runtime is downloaded from Adoptium into `.koldkitty` beside the executable.
- No system-wide Java installation or administrator access is required.
- This beta is unsigned. Windows may display a security warning.

Working notes
https://installation.koldsleep.com/

Mihyun KIM / koldsleep
koldsleep@gmail.com
