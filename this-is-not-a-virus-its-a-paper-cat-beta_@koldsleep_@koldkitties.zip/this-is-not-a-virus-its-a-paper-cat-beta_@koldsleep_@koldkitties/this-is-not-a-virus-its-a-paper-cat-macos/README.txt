바이러스가 아닙니다 종이 고양이 — beta
this is not a virus. it’s a paper cat. — beta

macOS

실행
- `koldkitty.app` 열기.
- 다시 실행하면 고양이가 한 마리 더 나타납니다.
- 고양이를 우클릭하면 해당 고양이만 종료됩니다.
- 고양이를 클릭하면 종이로 변하고, 약 4초 후 브라우저가 열립니다.

요구 사항
- Java 17 이상.
- 코드 서명 및 공증되지 않은 베타 버전입니다. 최초 실행 시 macOS의 확인 절차가 필요할 수 있습니다.

작업 노트
https://installation.koldsleep.com/

---

macOS

Run
- Open `koldkitty.app`.
- Open it again to add another cat.
- Right-click a cat to close that instance.
- Click a cat to turn it into paper; a browser page opens after approximately four seconds.

Requirements
- Java 17 or later.
- This beta is unsigned and not notarized. macOS may require additional confirmation on first launch.

Working notes
https://installation.koldsleep.com/

Mihyun KIM / koldsleep
koldsleep@gmail.com
