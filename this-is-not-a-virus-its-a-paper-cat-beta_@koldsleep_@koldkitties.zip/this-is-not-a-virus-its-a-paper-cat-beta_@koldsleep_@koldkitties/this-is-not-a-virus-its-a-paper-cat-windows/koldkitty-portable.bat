@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "KOLDDIR=%~dp0"
set "JAVAW="
if not exist "%KOLDDIR%koldkitty.jar" goto missingjar

rem Prefer installed Java from JAVA_HOME; do not download anything.
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javaw.exe" set "JAVAW=%JAVA_HOME%\bin\javaw.exe"
if not defined JAVAW for %%J in (javaw.exe) do set "JAVAW=%%~$PATH:J"

rem Other common vendor installation folders, if Java is not in PATH.
if not defined JAVAW for /d %%J in ("%ProgramFiles%\Eclipse Adoptium\jdk-*") do if exist "%%~fJ\bin\javaw.exe" set "JAVAW=%%~fJ\bin\javaw.exe"
if not defined JAVAW for /d %%J in ("%ProgramFiles%\Eclipse Adoptium\jre-*") do if exist "%%~fJ\bin\javaw.exe" set "JAVAW=%%~fJ\bin\javaw.exe"
if not defined JAVAW for /d %%J in ("%ProgramFiles%\Microsoft\jdk-*") do if exist "%%~fJ\bin\javaw.exe" set "JAVAW=%%~fJ\bin\javaw.exe"
if not defined JAVAW for /d %%J in ("%ProgramFiles%\Java\jdk-*") do if exist "%%~fJ\bin\javaw.exe" set "JAVAW=%%~fJ\bin\javaw.exe"
if not defined JAVAW for /d %%J in ("%ProgramFiles%\Java\jre-*") do if exist "%%~fJ\bin\javaw.exe" set "JAVAW=%%~fJ\bin\javaw.exe"

if not defined JAVAW goto missingjava
start "" "%JAVAW%" -Dfile.encoding=UTF-8 -jar "%KOLDDIR%koldkitty.jar"
if errorlevel 1 goto launcherror
exit /b 0

:missingjar
echo [koldkitty] koldkitty.jar is missing. Keep this file beside the launcher.
pause
exit /b 2

:missingjava
echo [koldkitty] Java 17 or later is required. No Java executable was found.
echo Install Eclipse Temurin JRE 17+ from https://adoptium.net/temurin/releases/
echo Then run koldkitty.bat again. No administrator privileges needed for this launcher.
pause
exit /b 3

:launcherror
echo [koldkitty] Could not launch Java. Check Java 17+ is installed.
pause
exit /b 4
