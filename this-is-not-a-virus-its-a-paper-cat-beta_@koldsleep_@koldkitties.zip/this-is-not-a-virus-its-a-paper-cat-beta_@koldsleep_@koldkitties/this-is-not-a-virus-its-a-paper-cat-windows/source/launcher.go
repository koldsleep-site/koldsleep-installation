package main

import (
	"archive/zip"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

//go:embed koldkitty.jar
var embeddedJar []byte

const (
	runtimeURL = "https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jre/hotspot/normal/eclipse?project=jdk"
	appDirName = ".koldkitty"
)

func main() {
	if runtime.GOOS != "windows" {
		return
	}

	exePath, err := os.Executable()
	if err != nil {
		showError("Could not locate koldkitty.exe.")
		return
	}
	baseDir := filepath.Dir(exePath)
	dataDir := filepath.Join(baseDir, appDirName)

	if err := os.MkdirAll(dataDir, 0755); err != nil {
		showError("koldkitty could not create its private data folder.\n\nMove the koldkitty folder somewhere writable and try again.")
		return
	}
	_ = setHidden(dataDir)

	jarPath := filepath.Join(dataDir, "koldkitty.jar")
	if err := ensureEmbeddedJar(jarPath); err != nil {
		showError("koldkitty could not prepare its application file.\n\n" + err.Error())
		return
	}

	javawPath := filepath.Join(dataDir, "runtime", "bin", "javaw.exe")
	if !fileExists(javawPath) {
		if err := ensureRuntime(dataDir, javawPath); err != nil {
			showError("koldkitty could not prepare its private Java runtime.\n\nCheck your internet connection and try again.\n\n" + err.Error())
			return
		}
	}

	cmd := exec.Command(javawPath, "-jar", jarPath)
	cmd.Dir = baseDir
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
	if err := cmd.Start(); err != nil {
		showError("koldkitty could not start.\n\n" + err.Error())
		return
	}
}

func ensureEmbeddedJar(path string) error {
	wanted := sha256.Sum256(embeddedJar)
	if b, err := os.ReadFile(path); err == nil {
		got := sha256.Sum256(b)
		if got == wanted {
			return nil
		}
	}

	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, embeddedJar, 0644); err != nil {
		return err
	}
	_ = os.Remove(path)
	if err := os.Rename(tmp, path); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func ensureRuntime(dataDir, javawPath string) error {
	lockDir := filepath.Join(dataDir, "runtime-install.lock")
	if err := os.Mkdir(lockDir, 0755); err != nil {
		if !os.IsExist(err) {
			return err
		}
		deadline := time.Now().Add(4 * time.Minute)
		for time.Now().Before(deadline) {
			if fileExists(javawPath) {
				return nil
			}
			time.Sleep(500 * time.Millisecond)
		}
		// Recover from a stale lock left by an interrupted first launch.
		_ = os.RemoveAll(lockDir)
		if err := os.Mkdir(lockDir, 0755); err != nil {
			return errors.New("another first-launch setup did not finish")
		}
	}
	defer os.RemoveAll(lockDir)

	if fileExists(javawPath) {
		return nil
	}

	showInfo("Preparing koldkitty's private Java 21 runtime.\n\nThis happens only on the first launch and requires an internet connection.")

	zipPath := filepath.Join(dataDir, "runtime-download.zip")
	tmpRuntime := filepath.Join(dataDir, "runtime-unpack")
	finalRuntime := filepath.Join(dataDir, "runtime")
	_ = os.Remove(zipPath)
	_ = os.RemoveAll(tmpRuntime)

	if err := download(runtimeURL, zipPath); err != nil {
		return fmt.Errorf("runtime download failed: %w", err)
	}
	defer os.Remove(zipPath)

	if err := unzipFlattenTopLevel(zipPath, tmpRuntime); err != nil {
		_ = os.RemoveAll(tmpRuntime)
		return fmt.Errorf("runtime extraction failed: %w", err)
	}

	candidateJava := filepath.Join(tmpRuntime, "bin", "javaw.exe")
	if !fileExists(candidateJava) {
		_ = os.RemoveAll(tmpRuntime)
		return errors.New("downloaded runtime did not contain bin\\javaw.exe")
	}

	_ = os.RemoveAll(finalRuntime)
	if err := os.Rename(tmpRuntime, finalRuntime); err != nil {
		_ = os.RemoveAll(tmpRuntime)
		return fmt.Errorf("could not install runtime: %w", err)
	}
	_ = setHidden(finalRuntime)

	if !fileExists(javawPath) {
		return errors.New("runtime installation did not complete correctly")
	}
	return nil
}

func download(url, dst string) error {
	client := &http.Client{Timeout: 5 * time.Minute}
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "koldkitty-beta/1.0")

	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("HTTP %s", resp.Status)
	}

	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	ok := false
	defer func() {
		out.Close()
		if !ok {
			os.Remove(dst)
		}
	}()

	if _, err := io.Copy(out, resp.Body); err != nil {
		return err
	}
	if err := out.Close(); err != nil {
		return err
	}
	ok = true
	return nil
}

func unzipFlattenTopLevel(zipPath, dst string) error {
	r, err := zip.OpenReader(zipPath)
	if err != nil {
		return err
	}
	defer r.Close()

	if err := os.MkdirAll(dst, 0755); err != nil {
		return err
	}

	for _, f := range r.File {
		name := filepath.ToSlash(f.Name)
		parts := strings.Split(name, "/")
		if len(parts) < 2 {
			continue
		}
		rel := filepath.FromSlash(strings.Join(parts[1:], "/"))
		if rel == "" || rel == "." {
			continue
		}
		clean := filepath.Clean(rel)
		if clean == ".." || strings.HasPrefix(clean, ".."+string(os.PathSeparator)) || filepath.IsAbs(clean) {
			return errors.New("unsafe path in runtime archive")
		}
		target := filepath.Join(dst, clean)
		if !strings.HasPrefix(strings.ToLower(filepath.Clean(target)), strings.ToLower(filepath.Clean(dst)+string(os.PathSeparator))) {
			return errors.New("unsafe path in runtime archive")
		}

		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0755); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil {
			return err
		}
		src, err := f.Open()
		if err != nil {
			return err
		}
		out, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
		if err != nil {
			src.Close()
			return err
		}
		_, copyErr := io.Copy(out, src)
		closeErr := out.Close()
		src.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
	}
	return nil
}

func fileExists(path string) bool {
	st, err := os.Stat(path)
	return err == nil && !st.IsDir()
}

func setHidden(path string) error {
	p, err := syscall.UTF16PtrFromString(path)
	if err != nil {
		return err
	}
	kernel32 := syscall.NewLazyDLL("kernel32.dll")
	getAttr := kernel32.NewProc("GetFileAttributesW")
	setAttr := kernel32.NewProc("SetFileAttributesW")
	attrs, _, callErr := getAttr.Call(uintptr(unsafe.Pointer(p)))
	if attrs == 0xFFFFFFFF {
		return callErr
	}
	const fileAttributeHidden = 0x2
	r, _, callErr := setAttr.Call(uintptr(unsafe.Pointer(p)), attrs|fileAttributeHidden)
	if r == 0 {
		return callErr
	}
	return nil
}

func showInfo(message string) {
	messageBox(message, "koldkitty — first launch", 0x40)
}

func showError(message string) {
	messageBox(message, "koldkitty", 0x10)
}

func messageBox(message, title string, flags uintptr) {
	user32 := syscall.NewLazyDLL("user32.dll")
	proc := user32.NewProc("MessageBoxW")
	msg, _ := syscall.UTF16PtrFromString(message)
	ttl, _ := syscall.UTF16PtrFromString(title)
	proc.Call(0, uintptr(unsafe.Pointer(msg)), uintptr(unsafe.Pointer(ttl)), flags)
}

func embeddedJarSHA256() string {
	sum := sha256.Sum256(embeddedJar)
	return hex.EncodeToString(sum[:])
}
