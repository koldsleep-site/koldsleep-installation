import javax.swing.JComponent;
import javax.swing.JWindow;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.net.URI;
import java.time.LocalTime;
import java.util.Random;

public final class koldkitty {
  private static final int GRID_W = 36;
  private static final int GRID_H = 24;
  private static final int PIXEL = 3;
  private static final int W = GRID_W * PIXEL;
  private static final int H = GRID_H * PIXEL;

  private static final int TOP_GAP = 4;

  private static final double DAY_SPEED = 1.6;
  private static final double NIGHT_SPEED = 18.0;
  private static final double FLEE_MULTIPLIER = 2.2;
  private static final double WATCH_SPEED_MULTIPLIER = 0.42;

  private static final double WATCH_RADIUS = 260.0;
  private static final double FLEE_RADIUS = 105.0;
  private static final long SURPRISE_DURATION = 340L;

  private static final int WALK = 0;
  private static final int SLEEP = 1;

  private static final int KITTY = 0;
  private static final int PAPER = 1;

  private static final long PAPER_FALL_DURATION = 4000L;
  private static final long PAPER_REST_AFTER_OPEN = 700L;

  private static final String INSTAGRAM_URL =
      "https://installation.koldsleep.com/";
  private static final String ARCHIVE_URL =
      "https://installation.koldsleep.com/";
  private static final String SLEEPINGSTRING_URL =
      "https://installation.koldsleep.com/";
  private static final String HOOP_RING_CHIME_URL =
      "https://installation.koldsleep.com/";

  private static final Random RNG = new Random();

  private JWindow window;
  private KittyView view;
  private Timer timer;
  private Rectangle workArea;

  private double x;
  private double y;
  private int direction = -1;

  private int state = WALK;
  private long stateStarted;
  private long stateDuration;

  private int form = KITTY;

  private double cursorX = -10000;
  private double cursorY = -10000;

  private boolean watching = false;
  private boolean fleeing = false;
  private boolean surprised = false;
  private boolean wasInsideFleeRadius = false;
  private long surpriseStartedAt = 0L;

  private double paperStartX;
  private double paperStartY;
  private double paperFallDistance = 220.0;
  private double paperDriftPrimary = 18.0;
  private double paperDriftSecondary = 7.0;
  private double paperWobbleCycles = 1.8;
  private double paperAngleAmplitude = 0.35;
  private double paperFinalAngle = 0.0;
  private long paperStartedAt = 0L;
  private double paperAngle = 0.0;
  private boolean paperLanded = false;
  private long paperLandedAt = 0L;
  private boolean portalOpened = false;
  private String pendingPortalURL = ARCHIVE_URL;

  private int activeSleepZ = 0;
  private int sleepZLiftAmount = 2;
  private long sleepZCycleStarted = 0L;
  private long sleepZCycleDuration = 850L;

  private long lastTick = System.currentTimeMillis();

  private static final String[] WALK1 = {
      "....................................",
      "....................................",
      "...##.......##.......................",
      "..####.....####......................",
      ".###############.....................",
      "#################....................",
      ".###############.....................",
      "..##############.....................",
      "..#############......................",
      "...######################...........",
      "....######################..........",
      ".....######################.........",
      "......######################........",
      "......######################........",
      ".......####################.........",
      "........##################..........",
      ".........#####..########............",
      "..........###....#####..............",
      "....................................",
      "....................................",
      "....................................",
      "....................................",
      "....................................",
      "...................................."
  };

  private static final String[] WALK2 = {
      "....................................",
      "....................................",
      "...##.......##.......................",
      "..####.....####......................",
      ".###############.....................",
      "#################....................",
      ".###############.....................",
      "..##############.....................",
      "..#############......................",
      "....#####################............",
      ".....######################..........",
      ".....#######################.........",
      "......######################.........",
      ".......#####################.........",
      ".......####################..........",
      "........##################...........",
      ".........#####..#######..............",
      "..........###....#####...............",
      "....................................",
      "....................................",
      "....................................",
      "....................................",
      "....................................",
      "...................................."
  };

  private static final String[] SLEEP_SPRITE = {
      "....................................",
      "....................................",
      "....................................",
      "....................................",
      ".....##.......##.....................",
      "....####.....####....................",
      "...###############..................",
      "..#################.................",
      "..########################..........",
      "...##########################.......",
      "....##########################......",
      ".....#########################......",
      "......########################......",
      "........#####################.......",
      "..........#################.........",
      "............############............",
      "...............########.............",
      "....................................",
      "....................................",
      "....................................",
      "....................................",
      "....................................",
      "....................................",
      "...................................."
  };


  public static void main(String[] args) {
    System.setProperty("apple.awt.UIElement", "true");
    SwingUtilities.invokeLater(() -> new koldkitty().start());
  }

  private void start() {
    workArea = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();

    window = new JWindow();
    window.setBackground(new Color(0, 0, 0, 0));
    window.setAlwaysOnTop(true);
    window.setFocusableWindowState(false);
    try {
      window.setType(Window.Type.UTILITY);
    } catch (RuntimeException ignored) {
      // Some desktop environments do not support window type hints.
    }
    window.setSize(W, H);

    view = new KittyView();
    view.setOpaque(false);
    window.setContentPane(view);

    window.addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isRightMouseButton(e)) {
          shutdown();
        }
      }

      @Override
      public void mouseClicked(MouseEvent e) {
        if (!SwingUtilities.isLeftMouseButton(e) || form != KITTY || view == null) {
          return;
        }

        long now = System.currentTimeMillis();

        // The JWindow itself is a transparent 108 x 72 rectangle. Without
        // hit-testing, clicking an invisible part of that rectangle can look
        // like the cat changed into paper by itself. Only pixels that are
        // actually drawn as the cat are allowed to trigger the transformation.
        if (!view.isVisibleCatPixel(e.getX(), e.getY(), now)) {
          return;
        }

        turnIntoPaper(now);
      }
    });

    respawnKitty();

    window.setLocation((int) Math.round(x), (int) Math.round(y));
    window.setVisible(true);

    timer = new Timer(33, e -> tick());
    timer.setCoalesce(true);
    timer.start();
  }

  private void tick() {
    long now = System.currentTimeMillis();
    double frameScale = Math.max(0.1, Math.min(2.0, (now - lastTick) / 33.333));
    lastTick = now;

    if (form == PAPER) {
      updatePaper(now);
      setWindowLocation();
      view.repaint();
      return;
    }

    updateCursor();
    updateCursorInteraction(now);

    if (surprised) {
      lookAtCursor();
    } else if (fleeing) {
      double center = x + W / 2.0;
      direction = cursorX < center ? 1 : -1;
      x += currentSpeed() * FLEE_MULTIPLIER * direction * frameScale;
    } else if (watching && state == WALK) {
      x += currentSpeed() * WATCH_SPEED_MULTIPLIER * direction * frameScale;
    } else if (state == WALK) {
      x += currentSpeed() * direction * frameScale;
    }

    if (!surprised && !fleeing && now - stateStarted > stateDuration) {
      chooseNextState(now);
    }

    constrainX();
    y = getCatY();
    setWindowLocation();
    view.repaint();
  }

  private void updateCursor() {
    try {
      PointerInfo info = MouseInfo.getPointerInfo();
      if (info != null) {
        Point p = info.getLocation();
        cursorX = p.x;
        cursorY = p.y;
      }
    } catch (Exception ignored) {
      cursorX = -10000;
      cursorY = -10000;
    }
  }

  private void updateCursorInteraction(long now) {
    double centerX = x + W / 2.0;
    double centerY = y + H / 2.0;
    double dx = cursorX - centerX;
    double dy = cursorY - centerY;
    double distance = Math.sqrt(dx * dx + dy * dy);

    if (distance < FLEE_RADIUS) {
      if (!wasInsideFleeRadius) {
        surpriseStartedAt = now;

        if (state == SLEEP) {
          state = WALK;
          stateStarted = now;
          stateDuration = randomLong(7000, 19000);
        }
      }

      wasInsideFleeRadius = true;

      if (now - surpriseStartedAt < SURPRISE_DURATION) {
        surprised = true;
        fleeing = false;
        watching = false;
      } else {
        surprised = false;
        fleeing = true;
        watching = false;
      }
    } else if (distance < WATCH_RADIUS) {
      wasInsideFleeRadius = false;
      surprised = false;
      fleeing = false;
      watching = state == WALK;
    } else {
      wasInsideFleeRadius = false;
      surprised = false;
      fleeing = false;
      watching = false;
    }
  }

  private void lookAtCursor() {
    double center = x + W / 2.0;
    direction = cursorX < center ? -1 : 1;
  }

  private double currentSpeed() {
    int hour = LocalTime.now().getHour();
    boolean night = hour >= 21 || hour < 9;
    return night ? NIGHT_SPEED : DAY_SPEED;
  }

  private double getCatY() {
    return workArea.y + TOP_GAP;
  }

  private void constrainX() {
    double minX = workArea.x;
    double maxX = workArea.x + workArea.width - W;

    if (x < minX) {
      x = minX;
      direction = 1;
    }

    if (x > maxX) {
      x = maxX;
      direction = -1;
    }
  }

  private void chooseNextState(long now) {
    if (state == WALK) {
      state = SLEEP;
      resetSleepZAnimation(now);
      stateDuration = randomLong(7000, 26000);
    } else {
      state = WALK;
      stateDuration = randomLong(7000, 19000);

      if (RNG.nextDouble() < 0.40) {
        direction *= -1;
      }
    }

    stateStarted = now;
  }

  private void resetSleepZAnimation(long now) {
    activeSleepZ = RNG.nextInt(3);
    sleepZLiftAmount = 1 + RNG.nextInt(2);
    sleepZCycleDuration = randomLong(650, 1100);
    sleepZCycleStarted = now;
  }

  private void choosePortalDestination() {
    double roll = RNG.nextDouble();

    // desktop beta link distribution:
    // Instagram 50% / Archive 10% / Sleeping String 20% / Hoop Ring Chime 20%
    if (roll < 0.50) {
      pendingPortalURL = INSTAGRAM_URL;
    } else if (roll < 0.60) {
      pendingPortalURL = ARCHIVE_URL;
    } else if (roll < 0.80) {
      pendingPortalURL = SLEEPINGSTRING_URL;
    } else {
      pendingPortalURL = HOOP_RING_CHIME_URL;
    }
  }

  private void turnIntoPaper(long now) {
    if (form != KITTY) return;

    form = PAPER;
    watching = false;
    fleeing = false;
    surprised = false;
    wasInsideFleeRadius = false;

    choosePortalDestination();

    paperStartX = x;
    paperStartY = y;

    double floorY = workArea.y + workArea.height - H;
    double availableDown = Math.max(0.0, floorY - paperStartY);

    // The paper falls for exactly four seconds, but it does not have to reach
    // the desktop floor. Each click gets a different, deliberately slow fall.
    double minFall = Math.min(80.0, availableDown);
    double maxFall = Math.min(360.0, availableDown);
    if (maxFall <= minFall) {
      paperFallDistance = availableDown;
    } else {
      paperFallDistance = randomDouble(minFall, maxFall);
    }

    paperDriftPrimary = randomDouble(8.0, 26.0);
    paperDriftSecondary = randomDouble(2.0, 10.0);
    paperWobbleCycles = randomDouble(1.1, 2.5);
    paperAngleAmplitude = randomDouble(0.16, 0.46);
    paperFinalAngle = randomDouble(-0.18, 0.18);

    paperStartedAt = now;
    paperAngle = randomDouble(-0.16, 0.16);
    paperLanded = false;
    paperLandedAt = 0L;
    portalOpened = false;
  }

  private void updatePaper(long now) {
    if (!paperLanded) {
      double t = Math.max(0.0, Math.min(1.0,
          (now - paperStartedAt) / (double) PAPER_FALL_DURATION));

      // Mostly linear, slow motion. The random distance chosen on click controls
      // how far it gets during these four seconds.
      double eased = t * (0.92 + 0.08 * t);
      double targetY = Math.min(
          workArea.y + workArea.height - H,
          paperStartY + paperFallDistance);
      double phase = t * Math.PI * 2.0 * paperWobbleCycles;

      x = paperStartX
          + Math.sin(phase) * paperDriftPrimary
          + Math.sin(phase * 0.43 + 0.8) * paperDriftSecondary;

      double minX = workArea.x;
      double maxX = workArea.x + workArea.width - W;
      x = Math.max(minX, Math.min(maxX, x));

      y = paperStartY + (targetY - paperStartY) * eased;
      paperAngle = Math.sin(phase * 1.15) * paperAngleAmplitude;

      if (t >= 1.0) {
        y = targetY;
        paperAngle = paperFinalAngle;
        paperLanded = true;
        paperLandedAt = now;
        openPortalOnce();
      }
      return;
    }

    if (now - paperLandedAt >= PAPER_REST_AFTER_OPEN) {
      respawnKitty();
    }
  }

  private void openPortalOnce() {
    if (portalOpened) return;
    portalOpened = true;

    try {
      if (Desktop.isDesktopSupported()) {
        Desktop.getDesktop().browse(URI.create(pendingPortalURL));
      }
    } catch (Exception ignored) {
      // Keep the cat alive even if a browser cannot be opened.
    }
  }

  private void respawnKitty() {
    workArea = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();

    form = KITTY;
    state = WALK;

    double minX = workArea.x + 20.0;
    double maxX = Math.max(minX + 1.0, workArea.x + workArea.width - W - 20.0);

    x = randomDouble(minX, maxX);
    y = getCatY();
    direction = RNG.nextBoolean() ? -1 : 1;

    stateStarted = System.currentTimeMillis();
    stateDuration = randomLong(7000, 18000);

    paperLanded = false;
    paperLandedAt = 0L;
    paperStartedAt = 0L;
    portalOpened = false;
  }

  private void setWindowLocation() {
    window.setLocation((int) Math.round(x), (int) Math.round(y));
  }

  private long randomLong(long min, long max) {
    return min + (long) Math.floor(RNG.nextDouble() * (max - min));
  }

  private double randomDouble(double min, double max) {
    return min + RNG.nextDouble() * (max - min);
  }

  private void shutdown() {
    if (timer != null) timer.stop();
    if (window != null) window.dispose();
    System.exit(0);
  }

  private final class KittyView extends JComponent {
    private final Font sleepFont = new Font(Font.MONOSPACED, Font.PLAIN, 10);

    private boolean isVisibleCatPixel(int mouseX, int mouseY, long now) {
      if (mouseX < 0 || mouseY < 0 || mouseX >= W || mouseY >= H || form != KITTY) {
        return false;
      }

      BufferedImage hitImage = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
      Graphics2D hg = hitImage.createGraphics();
      hg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
      hg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
      drawCat(hg, now);
      hg.dispose();

      return ((hitImage.getRGB(mouseX, mouseY) >>> 24) & 0xff) != 0;
    }

    @Override
    protected void paintComponent(Graphics g) {
      super.paintComponent(g);

      Graphics2D gg = (Graphics2D) g.create();
      gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
      gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);

      if (form == PAPER) {
        drawPaper(gg);
      } else {
        drawCat(gg, System.currentTimeMillis());
      }

      gg.dispose();
    }

    private void drawCat(Graphics2D g, long now) {
      if (state == SLEEP && !surprised && !fleeing) {
        drawSprite(g, SLEEP_SPRITE);
        drawSleepingTail(g);
        drawSleepingEyes(g);
        drawSleepZzz(g, now);
        return;
      }

      long frameSpeed = (fleeing || currentSpeed() == NIGHT_SPEED) ? 45L : 180L;
      int frame = (int) ((now / frameSpeed) % 2L);
      String[] sprite = (watching || surprised) ? WALK1 : (frame == 0 ? WALK1 : WALK2);

      Graphics2D cg = (Graphics2D) g.create();
      if (direction == 1) {
        cg.translate(W, 0);
        cg.scale(-1, 1);
      }

      drawSprite(cg, sprite);
      drawFullerFace(cg);
      drawFourShortLegs(cg, frame);
      drawTail(cg, frame);
      drawWhiskers(cg);

      if (surprised || fleeing) {
        drawBackSpikes(cg);
        drawSurprisedEyes(cg);
      } else {
        drawSlitEyes(cg);
      }

      cg.dispose();
    }

    private void drawSprite(Graphics2D g, String[] sprite) {
      g.setColor(Color.WHITE);
      for (int gy = 0; gy < sprite.length; gy++) {
        String row = sprite[gy];
        for (int gx = 0; gx < row.length(); gx++) {
          if (row.charAt(gx) == '#') {
            px(g, gx, gy, Color.WHITE);
          }
        }
      }
    }

    private void drawFullerFace(Graphics2D g) {
      int[][] p = {
          {1,6},{1,7},{1,8},{2,8},{2,9},{3,9},
          {15,6},{15,7},{16,7},{14,8},{15,8},{14,9},
          {4,9},{5,9},{11,9},{12,9},{13,9}
      };
      for (int[] v : p) px(g, v[0], v[1], Color.WHITE);
    }

    private void drawFourShortLegs(Graphics2D g, int frame) {
      int[][] p0 = {
          {9,15},{9,16},{8,17},{7,18},
          {13,15},{13,16},{14,17},{15,18},
          {19,15},{19,16},{18,17},{17,18},
          {23,15},{23,16},{24,17},{25,18}
      };
      int[][] p1 = {
          {9,15},{9,16},{10,17},{11,18},
          {13,15},{13,16},{12,17},{11,18},
          {19,15},{19,16},{20,17},{21,18},
          {23,15},{23,16},{22,17},{21,18}
      };
      for (int[] v : (frame == 0 ? p0 : p1)) px(g, v[0], v[1], Color.WHITE);
    }

    private void drawTail(Graphics2D g, int frame) {
      int[][] p0 = {
          {24,13},{25,13},{26,14},{27,14},{28,14},{29,13},
          {30,12},{31,11},{32,10},{33,9},{34,8},{35,8}
      };
      int[][] p1 = {
          {24,13},{25,13},{26,13},{27,14},{28,14},{29,13},
          {30,12},{31,11},{32,10},{33,9},{34,9},{35,8}
      };
      for (int[] v : (frame == 0 ? p0 : p1)) px(g, v[0], v[1], Color.WHITE);
    }

    private void drawSleepingTail(Graphics2D g) {
      int[][] p = {
          {22,13},{23,13},{24,14},{25,14},{26,14},{27,14},
          {28,13},{29,12},{30,11}
      };
      for (int[] v : p) px(g, v[0], v[1], Color.WHITE);
    }

    private void drawWhiskers(Graphics2D g) {
      g.setColor(Color.WHITE);
      g.fillRect(0, 23, 14, 1);
      g.fillRect(2, 28, 12, 1);
      g.fillRect(0, 34, 11, 1);
      g.fillRect(38, 22, 15, 1);
      g.fillRect(40, 28, 13, 1);
      g.fillRect(41, 35, 10, 1);
    }

    private void drawSlitEyes(Graphics2D g) {
      g.setColor(Color.BLACK);
      g.fillRect(12, 20, 8, 2);
      g.fillRect(28, 21, 8, 2);
    }

    private void drawSleepingEyes(Graphics2D g) {
      g.setColor(Color.BLACK);
      g.fillRect(17, 22, 7, 1);
      g.fillRect(30, 22, 7, 1);
    }

    private void drawSleepZzz(Graphics2D g, long now) {
      if (sleepZCycleStarted == 0L) {
        resetSleepZAnimation(now);
      }

      long elapsed = now - sleepZCycleStarted;
      if (elapsed >= sleepZCycleDuration) {
        resetSleepZAnimation(now);
        elapsed = 0L;
      }

      double t = elapsed / (double) sleepZCycleDuration;
      int lift = (int) Math.round(-sleepZLiftAmount * Math.sin(Math.PI * t));
      int[] ys = {17, 17, 17};
      ys[activeSleepZ] += lift;

      g.setColor(Color.WHITE);
      g.setFont(sleepFont);
      g.drawString("z", 73, ys[0]);
      g.drawString("z", 82, ys[1]);
      g.drawString("z", 91, ys[2]);
    }

    private void drawBackSpikes(Graphics2D g) {
      int[][] p = {
          {13,10},{13,9},{12,8},
          {15,10},{15,9},
          {17,10},{17,9},{17,8},{18,7},
          {20,10},{20,9},{21,8},
          {23,10},{23,9},{24,9},
          {25,11},{25,10},{26,9}
      };
      for (int[] v : p) px(g, v[0], v[1], Color.WHITE);
    }

    private void drawSurprisedEyes(Graphics2D g) {
      g.setColor(Color.BLACK);
      g.fillRect(16,17,8,3);
      g.fillRect(16,28,8,3);
      g.fillRect(13,20,3,8);
      g.fillRect(24,20,3,8);

      g.fillRect(28,17,8,3);
      g.fillRect(28,28,8,3);
      g.fillRect(26,20,3,8);
      g.fillRect(36,20,3,8);
    }

    private void drawPaper(Graphics2D g) {
      Graphics2D pg = (Graphics2D) g.create();
      pg.translate(W / 2.0, H / 2.0);
      pg.rotate(paperAngle);
      pg.translate(-W / 2.0, -H / 2.0);

      // A4-like pixel paper: pure white face, only a very thin 1px gray outline.
      int paperX = 12 * PIXEL;
      int paperY = 3 * PIXEL;
      int paperW = 11 * PIXEL;
      int paperH = 15 * PIXEL;

      pg.setColor(Color.WHITE);
      pg.fillRect(paperX, paperY, paperW, paperH);

      pg.setColor(new Color(185, 185, 185));
      pg.drawRect(paperX, paperY, paperW - 1, paperH - 1);

      pg.dispose();
    }

    private void px(Graphics2D g, int gx, int gy, Color color) {
      g.setColor(color);
      g.fillRect(gx * PIXEL, gy * PIXEL, PIXEL, PIXEL);
    }
  }
}
