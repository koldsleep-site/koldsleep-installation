바이러스가 아닙니다 종이 고양이 — beta
Windows 10 / 11 x64  |  link-only update: 2026-10-09

변경 사항
- 원본 Java 소스의 네 링크만 https://installation.koldsleep.com/ 으로 통일했습니다.
- 클릭할 때마다 링크를 선택하는 기존 확률 분기 및 고양이 동작은 그대로 유지했습니다.
- Windows launcher.go 소스는 이전 배포본과 동일합니다.

실행 방법 A: 기존 방식
- koldkitty.exe 를 실행하세요.
- 첫 실행 시 Adoptium에서 Java 21을 자동으로 내려받아 실행 파일 옆 .koldkitty 폴더에 보관합니다.
- 관리자 권한은 필요하지 않습니다.
- 이 실행 파일은 코드 서명되지 않았습니다. 일부 백신은 경고하거나 차단할 수 있습니다.
- 백신이 악성코드를 탐지하면 차단을 임의로 해제하지 말고 파일을 검증해 주세요.

실행 방법 B: 자동 다운로드 없는 대안
- Java 17 이상이 설치된 Windows에서 koldkitty-portable.bat 를 실행하세요.
- koldkitty.jar 를 같은 폴더에 두세요.
- 이 실행 방식은 자동 다운로드 및 .koldkitty 숨김 폴더 생성을 하지 않습니다.
- 다운로드: https://adoptium.net/temurin/releases/

참고
- macOS 파일은 포함하지 않았으며 Windows x64용입니다.
- Windows 환경에서 실제 실행 및 Defender 탐지 검증을 완료하지 않았습니다.
- 개발 기록: https://installation.koldsleep.com/

Mihyun KIM / koldsleep
koldsleep@gmail.com
